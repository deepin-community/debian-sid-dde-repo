#!/bin/bash

nohup /usr/bin/dlmextensionservice &
