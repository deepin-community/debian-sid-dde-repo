#!/bin/bash

. /usr/lib/deepin-graphics-driver-manager/common.sh

modify_config "gltest-success" "true"
