// SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef FILEMENUMANAGER_H
#define FILEMENUMANAGER_H

#include "dfmglobal.h"

#include <QAction>

#include <QObject>
#include <QMap>
#include <QSet>

#define MENU_HIDDEN "dfm.menu.hidden"
#define DFM_MENU_ACTION_HIDDEN "dfm.menu.action.hidden"
#define DD_MENU_ACTION_HIDDEN "dd.menu.action.hidden"
#define DFD_MENU_ACTION_HIDDEN "dfd.menu.action.hidden"

class DFileMenu;
class DUrl;
typedef DFMGlobal::MenuAction MenuAction;
typedef QList<DUrl> DUrlList;

class DFileMenuManager : public QObject
{
    Q_OBJECT

public:
    //fix:临时获取光盘刻录前临时的缓存地址路径，便于以后直接获取使用
    static QString fmblkDevice;

    DFileMenuManager();
    ~DFileMenuManager();

    static DFileMenu *createDefaultBookMarkMenu(const QSet<MenuAction> &disableList = QSet<MenuAction>());
    static DFileMenu *createUserShareMarkMenu(const QSet<MenuAction> &disableList = QSet<MenuAction>());
    static DFileMenu *createToolBarSettingsMenu(const QSet<MenuAction> &disableList = QSet<MenuAction>());

    static DFileMenu *createNormalMenu(const DUrl &currentUrl, const DUrlList &urlList, QSet<MenuAction> disableList, QSet<MenuAction> unusedList, int windowId, bool onDesktop);
    static DFileMenu *createVaultMenu(QWidget *topWidget, const QObject *sender = nullptr);

    static QList<QAction *> loadNormalPluginMenu(DFileMenu *menu, const DUrlList &urlList, const DUrl &currentUrl, bool onDesktop);
    static QList<QAction *> loadEmptyAreaPluginMenu(DFileMenu *menu, const DUrl &currentUrl, bool onDesktop);

    static QAction *getAction(MenuAction action);
    static QString getActionText(MenuAction action);

    static QSet<MenuAction> getDisableActionList(const DUrl &fileUrl);
    static QSet<MenuAction> getDisableActionList(const DUrlList &urlList);

    static DFileMenu *genereteMenuByKeys(const QVector<MenuAction> &keys,
                                         const QSet<MenuAction> &disableList,
                                         bool checkable = false,
                                         const QMap<MenuAction, QVector<MenuAction> > &subMenuList = QMap<MenuAction, QVector<MenuAction> >(),
                                         bool isUseCachedAction = true,
                                         bool isRecursiveCall = false);
    static QString getActionString(MenuAction type);
    static bool needDeleteAction();

    static void extendCustomMenu(DFileMenu *menu, bool isNormal,
                                 const DUrl &dir,
                                 const DUrl &focusFile,
                                 const DUrlList &selected = {},
                                 bool onDesktop = false);
    static void extensionPluginCustomMenu(DFileMenu *menu, bool isNormal,
                                              const DUrl currentUrl,
                                              const DUrl focusFile,
                                              const DUrlList &selected = {},
                                              bool onDesktop = false);

    static bool isCustomMenuSupported(const DUrl &viewRootUrl);
    static bool isExtensionsSupported(const DUrl &viewRootUrl);

    /// actions filter(global)
    static void addActionWhitelist(MenuAction action);
    static void setActionWhitelist(const QSet<MenuAction> &actionList);
    static QSet<MenuAction> actionWhitelist();
    static void addActionBlacklist(MenuAction action);
    static void setActionBlacklist(const QSet<MenuAction> &actionList);
    static QSet<MenuAction> actionBlacklist();
    static bool isAvailableAction(MenuAction action);

    static QList<QMap<QString, QString>> ExtensionMenuItems;


    static void setActionString(MenuAction type, QString actionString);
    static void setActionID(MenuAction type, QString id);

    static MenuAction registerMenuActionType(QAction *action);

    static bool whetherShowTagActions(const QList<DUrl> &urls);

    static void clearActions();

    static bool menuHidden(const QString &scene);
    static void menuFilterHiddenActions(QMenu *menu, const QString &scene);
    static QString getActionPredicateByType(MenuAction type);
    static void resetAllActionVisibility(bool visible);

private:
    static void commitReportData(QAction *action, DFileMenu *menu);

public slots:
    void actionTriggered(QAction *action);
};

#endif // FILEMENUMANAGER_H
