set(DTKCORE_INCLUDE_DIR /usr/include/libdtk-5.5.32/DCore)
set(DTKCORE_TOOL_DIR /usr/lib/x86_64-linux-gnu/libdtk-5.5.32/DCore/bin)
set(DtkCore_LIBRARIES dtkcore)
include_directories("${DTKCORE_INCLUDE_DIR}")
