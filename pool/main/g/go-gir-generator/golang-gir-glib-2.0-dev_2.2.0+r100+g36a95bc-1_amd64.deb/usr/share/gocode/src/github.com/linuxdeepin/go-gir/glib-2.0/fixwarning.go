// SPDX-FileCopyrightText: 2018 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

package glib

import "C"
import "unsafe"

//export _GLib_go_callback_cleanup
func _GLib_go_callback_cleanup(unsafe.Pointer) {
}
